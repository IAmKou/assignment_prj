package com.hust.aims.views.screens.placeorder;
import java.awt.TextField;

import javafx.fxml.FXML;

public class UnavailableProductScreen {
    @FXML
    TextField unavailableProductsDisplay;

    // called by the FXML loader after the labels declared above are injected:
    public void initialize() {
//        unavailableProductsDisplay.setText(ViewCartController.str);
    }
}
