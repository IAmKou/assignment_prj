package com.hust.aims.module;

public class Item {
    private String name;
    private String price;
    private String quantity;

    public Item(String price, String quantity, String name) {
        this.price = price;
        this.quantity = quantity;
        this.name = name;
    }
}
